from calculos.OperacionesMatematicas import sumar, potenciar

from calculos.basicos.OperacionesMatematicasBasicas import restar
from calculos.avanzados.OperacionesMatematicasAvanzadas import redondear

def main ():
    print(sumar(1,2))
    print(potenciar(5,3))

    print(restar(5, -9))
    print(redondear(3.2))
    
main()