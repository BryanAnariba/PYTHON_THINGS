from setuptools import setup
setup (
    name = "PaqueteDeCalculos",
    version = "0.0.1",
    description = "Para realizar operaciones basicas y avanzadas en matematicas",
    author = "Bryan Ariel Sanchez Anariba",
    author_email  ="saariel115@gmail.com",
    url = "www.github.com",
    packages = [ "paquetes", "paquetes.calculos" ]
)